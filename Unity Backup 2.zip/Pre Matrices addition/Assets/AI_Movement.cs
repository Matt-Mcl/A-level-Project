﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class AI_Movement : MonoBehaviour
{
    private Vector3 target;
    private Quaternion rotation;
    private Vector3 position;
    public Movement playerScript;
    //private int move;
    private float dirNum;
    private Vector3 heading;
    public int[,] matrix = new int[8, 8];

    // Use this for initialization
    void Start()
    {
        target = transform.TransformPoint(0, 0, 0);
    }

    // Update is called once per frame
    void Update()
    {
        float step = 100.0f * Time.deltaTime;
        float rot = 5.0f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, step);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rot);
        heading = playerScript.plane1Position - transform.position;
        dirNum = AngleDir(transform.forward, heading, transform.up);
        //print(dirNum);
    }


    public float AngleDir(Vector3 fwd, Vector3 targetDir, Vector3 up)
    {
        Vector3 perp = Vector3.Cross(fwd, targetDir);
        float dir = Vector3.Dot(perp, up);
        return dir;
        /*
        if (dir > 0.0f)
        {
            return 1.0f;
        }
        else if (dir < 0.0f)
        {
            return -1.0f;
        }
        else
        {
            return 0.0f;
        }
        */
    }

    public void FillMatrix(int[,] matrix)
    {
        for (int i = 0; i < 8;) 
        {
            matrix[i, 0] = 1;
        }
    }

    public void PrintMatrix(int[,] matrix) {
        string row = "";
        for(int i = 0;i < 8;i++) {
            row = "";
            for(int j = 0;j < 8;j++) {
                row = row + " " + matrix[i, j];
            }
            Debug.Log(row);
        }

    }

    public void AiMove()
    {
        FillMatrix(matrix);
        PrintMatrix(matrix);

        float distance = Vector3.Distance(playerScript.plane1Position, transform.position);
        print("DirNum: " + dirNum);
        print("Distance: " + distance);
        if (dirNum < -100)
        {
            if (distance > 250)
            {
                print("Moved far left");
                MoveFarLeft();
            }
            else
            {
                print("Moved close left");
                MoveCloseLeft();
            }

        }
        else if (dirNum > 100)
        {
            if (distance > 250)
            {
                print("Moved far right");
                MoveFarRight();
            }
            else
            {
                print("Moved close right");
                MoveCloseRight();
            }

        }
        else
        {
            MoveCloseForward();
            print("Moved back left");
        }
    }




    /*
    public void AiMove()
    {
        print(Argument(playerScript.plane1Position));
        print(transform.forward);
        print(Argument(transform.forward));
        if ((Argument(playerScript.plane1Position) - Argument(new Vector3 (Mathf.Cos(transform.position.x), Mathf.Sin(transform.position.y),0)) < 0))
        {
            MoveCloseRight();
            print("Right of AI");
        }

        else
        {
            MoveCloseLeft();
            print("Left of AI");
        }

    }

    public float Argument(Vector3 vector)
    {
        float angle = Mathf.Atan(vector.y / vector.x);
        if (vector.x < 0 && vector.y < 0)
        {
            angle += Mathf.PI;
        }
        return angle;
    }
    /*

    /*
    move = Random.Range(1, 7);
    if (move == 1)
    {
        MoveCloseForward();
    }
    if (move == 2)
    {
        MoveCloseRight();
    }
    if (move == 3)
    {
        MoveCloseLeft();
    }
    if (move == 4)
    {
        MoveFarForward();
    }
    if (move == 5)
    {
        MoveFarRight();
    }
    if (move == 6)
    {
        MoveFarLeft();
    }
    */

    public void MoveCloseForward()
    {
        target = transform.TransformPoint(0, 95, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);        
    }

    public void MoveCloseRight()
    {
        target = transform.TransformPoint(35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -30);
    }

    public void MoveCloseLeft()
    {
        target = transform.TransformPoint(-35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 30);
    }

    public void MoveFarForward()
    {
        target = transform.TransformPoint(0, 120, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);             
    }

    public void MoveFarRight()
    {
        target = transform.TransformPoint(40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -45);
    }

    public void MoveFarLeft()
    {
        target = transform.TransformPoint(-40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 45);
    }
    
    public void MoveBackLeft()
    {
        target = transform.TransformPoint(-20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

    public void MoveBackRight()
    {
        target = transform.TransformPoint(20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

}

