﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {
    private Vector3 target;
    private Quaternion rotation;
    private Vector3 position;
    public Vector3 plane1Position;
    public Quaternion plane1Rotation;
    public bool inBounds;
    private int move;

    // Use this for initialization
    void Start () {
        target = transform.TransformPoint(0, 0, 0);
    }

    // Update is called once per frame
    void Update () {
        float step = 100.0f * Time.deltaTime;
        float rot = 5.0f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, step);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rot);
        plane1Position = transform.position;
        plane1Rotation = transform.rotation;
    }
    

    public void MoveCloseForward()
    {
        move = 1;

    }

    public void MoveCloseRight()
    {
        move = 2;
    }

    public void MoveCloseLeft()
    {
        move = 3;
    }

    public void MoveFarForward()
    {
        move = 4;
    }

    public void MoveFarRight()
    {
        move = 5;
    }

    public void MoveFarLeft()
    {
        move = 6;
    }

    public void MoveBackLeft()
    {
        move = 7;
    }

    public void MoveBackRight()
    {
        move = 8;
    }

    public void PlayerMove()
    {
        if (move == 1) //MoveCloseForward
        {
            target = transform.TransformPoint(0, 95, 0);
            rotation = transform.rotation * Quaternion.Euler(0, 0, 0);
        }
        if (move == 2) //MoveCloseRight
        {
            target = transform.TransformPoint(35, 90, 0);
            rotation = transform.rotation * Quaternion.Euler(0, 0, -30);
        }
        if (move == 3) //MoveCloseLeft
        {
            target = transform.TransformPoint(-35, 90, 0);
            rotation = transform.rotation * Quaternion.Euler(0, 0, 30);
        }
        if (move == 4) //MoveFarForward
        {
            target = transform.TransformPoint(0, 120, 0);
            rotation = transform.rotation * Quaternion.Euler(0, 0, 0);
        }
        if (move == 5) //MoveFarRight
        {
            target = transform.TransformPoint(40, 105, 0);
            rotation = transform.rotation * Quaternion.Euler(0, 0, -45);
        }
        if (move == 6) //MoveFarLeft
        {
            target = transform.TransformPoint(-40, 105, 0);
            rotation = transform.rotation * Quaternion.Euler(0, 0, 45);
        }
        if (move == 7) //MoveBackLeft
        {
            target = transform.TransformPoint(-20, -90, 0);
            rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
        }
        if (move == 8) //MoveBackRight
        {
            target = transform.TransformPoint(20, -90, 0);
            rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
        }
    }

 }
