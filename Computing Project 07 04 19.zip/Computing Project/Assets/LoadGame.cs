﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadGame : MonoBehaviour {

    public Movement playerScript;
    public AI_Movement aiScript;
    public MenuUI menuScript;
    public GameUI gameScript;
    private float playerX;
    private float playerY;
    private float playerRotation;
    private float AIX;
    private float AIY;
    private float AIRotation;


    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    
    public void Load()
    {
        playerX = PlayerPrefs.GetFloat("plane1PositionX", playerScript.plane1Position.x);
        playerY = PlayerPrefs.GetFloat("plane1PositionY", playerScript.plane1Position.y);
        playerRotation = PlayerPrefs.GetFloat("plane1Rotation", playerScript.plane1SaveRotation);

        AIX = PlayerPrefs.GetFloat("plane2PositionX", aiScript.transform.position.x);
        AIY = PlayerPrefs.GetFloat("plane2PositionY", aiScript.transform.position.y);
        AIRotation = PlayerPrefs.GetFloat("plane2Rotation", aiScript.plane2SaveRotation);

        print("Loaded");

        menuScript.BeginGame();
        gameScript.BeginGame();

        print("x, y: " + playerX + " " + playerY);
        print("x, y: " + AIX + " " + AIY);


        playerScript.target = transform.TransformPoint(playerX, playerY, 200);
        aiScript.target = transform.TransformPoint(AIX, AIY, 200);
        playerScript.LoadRotation(playerRotation);
        aiScript.LoadRotation(AIRotation);

    }
    
}
