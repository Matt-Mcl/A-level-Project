﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameEnd : MonoBehaviour {

    public GameUI gameUIScript;
    //public MenuUI menuUIScript;


    // Use this for initialization
    void Start () {
        foreach (Transform child in transform)
        {
            child.gameObject.SetActive(false);
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void EndGame(bool show)
    {
        if (show == true)
        {
            foreach (Transform child in transform)
            {
                child.gameObject.SetActive(show);
            }
            //gameUIScript.GameToggle(false);
        }

    }

}
