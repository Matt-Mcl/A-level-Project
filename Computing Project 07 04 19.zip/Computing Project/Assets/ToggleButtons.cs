﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ToggleButtons : MonoBehaviour {

   
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    
    public void ButtonToggle(bool enable)
    {
        int children = transform.childCount;
        for (int i = 0; i < children; ++i)
        {
            transform.GetChild(i).gameObject.GetComponent<Image>().enabled = enable;
        }
    }

    public bool GetButtonsEnabled()
    {
        return transform.GetChild(0).gameObject.GetComponent<Image>().enabled;
    }

}
