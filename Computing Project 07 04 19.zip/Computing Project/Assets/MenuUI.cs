﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuUI : MonoBehaviour {

	// Use this for initialization
	void Start()
	{

	}

	// Update is called once per frame
	void Update()
	{

	}

	public void BeginGame()
	{
		print("Start Clicked (menu)");
		MenuToggle(false);
	}

	public void MenuToggle(bool show)
	{
		foreach (Transform child in transform)
		{
			child.gameObject.SetActive(show);
		}
	}

}