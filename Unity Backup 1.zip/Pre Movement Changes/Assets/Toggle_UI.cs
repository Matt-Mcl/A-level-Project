﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Toggle_UI : MonoBehaviour
{
    private bool toggleCUI = true;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    
    public void changeUIState()
        ///Allows the plus button within the UI to toggle the control interface on and off
    {
        if(toggleCUI)
        {
            //Debug.Log("Off");
            gameObject.SetActive(false);
            toggleCUI = false;
        }
        else
        {
            //Debug.Log("On");
            gameObject.SetActive(true);
            toggleCUI = true;
        }
    }

}