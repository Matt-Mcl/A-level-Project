﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {

    public Toggle_UI uiScript;
    public Movement playerScript;
    public AI_Movement aiScript;
    public ToggleButtons buttonDisable;
    private bool playerTurn = true;
    private float turnTime;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(playerTurn);
        if (playerTurn == true)
        {
            if (Time.time - turnTime > 3)
            {
                buttonDisable.toggleButtons(true);
            }
        }

        if (playerTurn == false)
        {
            buttonDisable.toggleButtons(false);
            if (Time.time - turnTime > 3)
            {
                aiScript.AiMove();
                playerTurn = true;
                turnTime = Time.time;
            }
        }
    }

    public void ChangeTurn()
    {
        playerTurn = !playerTurn;
        turnTime = Time.time;
    }

}
