﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneCollisions : MonoBehaviour
{

    public bool collided;

    // Use this for initialization
    void Start()
    {
        collided = false;
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        collided = true;
        Debug.Log("Collided: " + collided);
    }

    void OnTriggerExit2D(Collider2D other)
    {
        collided = false;
        Debug.Log("Collided: " + collided);
    }

}

