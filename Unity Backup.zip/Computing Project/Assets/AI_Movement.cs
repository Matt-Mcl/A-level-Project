﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Movement : MonoBehaviour
{
    private Vector3 target;
    private Quaternion rotation;
    private Vector3 position;
    public Movement playerScript;
    public Vector3 plane2Position;
    public Quaternion plane2Rotation;
    private float dirNum;
    private Vector3 heading;
    private float distanceAway;
    private float angle;

    //debug vars

    //

    public Tuple3[,] matrix = new Tuple3[8, 8]; //FOR DESIGN: discuss why I chose tuple3 over 3d array / (3 arrays)
    
    public class Tuple3
    {
        public float distance;
        public float dirToPlayer;
        public float playerToAI;

        public Tuple3(float dist, float dtp, float pta)
        {
            this.distance = dist;
            this.dirToPlayer = dtp;
            this.playerToAI = pta;
        }

        public string Get()
        {
            return string.Concat(this.distance+","+this.dirToPlayer+","+this.playerToAI);
        }

    }

    // Use this for initialization
    void Start()
    {
        target = transform.TransformPoint(0, 0, 0);
        EmptyMatrix(matrix);
        //print("AI Pos = "+transform.position);
    }

    // Update is called once per frame
    void Update()
    {
        float step = 100.0f * Time.deltaTime;
        float rot = 5.0f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, step);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rot);
        plane2Position = transform.position;
        plane2Rotation = transform.rotation;
        distanceAway = Vector3.Distance(playerScript.plane1Position, transform.position);
        heading = playerScript.plane1Position - transform.position;
        angle = Vector3.Dot(heading, transform.up);
        //dirNum = AngleDir(transform.forward, heading, transform.up);
        //print(angle);
    }

    public float AngleDir(Vector3 fwd, Vector3 targetDir, Vector3 up) 
    {
        Vector3 perp = Vector3.Cross(fwd, targetDir);
        float dir = Vector3.Dot(perp, up);
        return dir;
    }

    public void EmptyMatrix(Tuple3[,] matrix) //Fills matrix with (0,0,0) tuples (emptying it)
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                matrix[i, j] = new Tuple3(0, 0, 0);
            }

        }

    }

    public Tuple3 CreateData(int i, int j)
    {
        Vector3 player = playerScript.plane1Position;
        Vector3 ai = transform.position;

        if (i == 0) {
            player += new Vector3(0, 95, 0);
        }
        if (i == 1)
        {
            player += new Vector3(35, 90, 0);
        }

        if (j == 0)
        {
            ai += new Vector3(0, 95, 0);
        }
        if (j == 1)
        {
            ai += new Vector3(35, 90, 0);
        }


        float distance = Vector3.Distance(player, ai);

        Vector3 heading1 = player - ai;
        float dirToPlayer = AngleDir(transform.forward, heading1, transform.up);

        Vector3 heading2 = ai - player;
        float dirToAi = AngleDir(playerScript.transform.forward, heading2, playerScript.transform.up);

        return new Tuple3(distance,dirToPlayer,dirToAi);
    }

    /*
    public void FillMatrix(Tuple3[,] matrix)
    {
        for (int i = 0; i < 8; i++) 
        {
            for (int j = 0; j < 8; j++)
            {
                matrix[i, j] = new Tuple3(UnityEngine.Random.Range(1, 100), UnityEngine.Random.Range(1, 100), UnityEngine.Random.Range(1, 100));
            }
        }
    }
    */

    public void FillMatrix(Tuple3[,] matrix)
    {
        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < 2; j++)
            {
                matrix[i,j] = CreateData(i,j);
            }
        }

        //matrix[0, 0] = new Tuple3(distanceAway, AngleDir(transform.forward, (playerScript.plane1Position + new Vector3(0, 95, 0)) - (transform.position + new Vector3(0, 95, 0)), transform.up), playerScript.dirToAi);
        //matrix[1,1] = new Tuple3(distanceAway, AngleDir(transform.forward, (playerScript.plane1Position + new Vector3(35, 90, 0)) - (transform.position + new Vector3(35, 90, 0)), transform.up), playerScript.dirToAi);
        //matrix[0, 1] = new Tuple3(distanceAway);

        //matrix[5, 5] = new Tuple3(distanceAway, dirNum, playerScript.dirToAi);
    }

    public void PrintMatrix(Tuple3[,] matrix) {
        string row = "";
        for(int i = 0;i < 8;i++)
        {
            row = "";
            for(int j = 0;j < 8;j++)
            {
                row = row + "|" + matrix[i, j].Get();
            }
            Debug.Log(row);
        }

    }

    public void AiMove()
    {
        FillMatrix(matrix);
        PrintMatrix(matrix);

        //MoveCloseRight();

        /*
        print("DirNum: " + dirNum);
        print("Distance: " + distanceAway);
        if (dirNum < -100)
        {
            if (distanceAway > 250)
            {
                print("Moved far left");
                MoveFarLeft();
            }
            else
            {
                print("Moved close left");
                MoveCloseLeft();
            }

        }
        else if (dirNum > 100)
        {
            if (distanceAway > 250)
            {
                print("Moved far right");
                MoveFarRight();
            }
            else
            {
                print("Moved close right");
                MoveCloseRight();
            }

        }
        else
        {
            MoveCloseForward();
            print("Moved back left");
        }
        */
    }


    public void MoveCloseForward()
    {
        target = transform.TransformPoint(0, 95, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);        
    }

    public void MoveCloseRight()
    {
        target = transform.TransformPoint(35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -30);
    }

    public void MoveCloseLeft()
    {
        target = transform.TransformPoint(-35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 30);
    }

    public void MoveFarForward()
    {
        target = transform.TransformPoint(0, 120, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);             
    }

    public void MoveFarRight()
    {
        target = transform.TransformPoint(40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -45);
    }

    public void MoveFarLeft()
    {
        target = transform.TransformPoint(-40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 45);
    }
    
    public void MoveBackLeft()
    {
        target = transform.TransformPoint(-20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

    public void MoveBackRight()
    {
        target = transform.TransformPoint(20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

}

