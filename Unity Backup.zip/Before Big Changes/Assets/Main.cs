﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {

    private GameObject plane1;
    private GameObject plane2;
    //private GameObject controlUI;
    private Vector3 target;
    private Quaternion rotation;
    private Vector3 position;
    private int move;
    //Toggle_UI uiScript = GetComponent<Toggle_UI>();
    private Toggle_UI uiScript;
    private Movement playerScript;
    private AI_Movement aiScript;


    // Use this for initialization
    void Start()
    {
        target = transform.TransformPoint(0, 0, 0);
        plane1 = GameObject.Find("Plane1");
        plane2 = GameObject.Find("Plane2"); 
        //controlUI = GameObject.Find("ControlUI");
        uiScript = GameObject.Find("ControlUI").GetComponent<Toggle_UI>();
        playerScript = GameObject.Find("Plane1").GetComponent<Movement>();
        aiScript = GameObject.Find("Plane2").GetComponent<AI_Movement>();
    }

    // Update is called once per frame
    void Update()
    {
        float step = 100.0f * Time.deltaTime;
        float rot = 3.0f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, step);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rot);
    }

    public void AiMove()
    {
        move = Random.Range(1, 7);
        if (move == 1)
        {
            MoveCloseForward();
        }
        if (move == 2)
        {
            MoveCloseRight();
        }
        if (move == 3)
        {
            MoveCloseLeft();
        }
        if (move == 4)
        {
            MoveFarForward();
        }
        if (move == 5)
        {
            MoveFarRight();
        }
        if (move == 6)
        {
            MoveFarLeft();
        }
    }

    public void MoveCloseForward()
    {
        target = transform.TransformPoint(0, 95, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);     
        uiScript.changeUIState();
        MoveFarRight();
    }

    public void MoveCloseRight()
    {
        target = transform.TransformPoint(35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -30);
    }

    public void MoveCloseLeft()
    {
        target = transform.TransformPoint(-35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 30);
    }

    public void MoveFarForward()
    {
        target = transform.TransformPoint(0, 120, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);             
    }

    public void MoveFarRight()
    {
        target = transform.TransformPoint(40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -45);
    }

    public void MoveFarLeft()
    {
        target = transform.TransformPoint(-40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 45);
    }

    public void main()
    {

    }
}
