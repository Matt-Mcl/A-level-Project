﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Movement : MonoBehaviour
{
    private Vector3 target;
    private Quaternion rotation;
    private Vector3 position;
    public Movement playerScript;
    private float dirNum;
    private Vector3 heading;

    //debug vars

    //

    public Tuple3[,] matrix = new Tuple3[8, 8]; //FOR DESIGN: discuss why chose 3d arry or tuple3
    
    public class Tuple3
    {
        public int distance;
        public int dirToPlayer;
        public int dirToAI;
        
        public Tuple3(int dist, int dtp, int dta)
        {
            this.distance = dist;
            this.dirToPlayer = dtp;
            this.dirToAI = dta;
        }

        public string Get()
        {
            return string.Concat(this.distance+","+this.dirToPlayer+","+this.dirToAI);
        }

    }

    // Use this for initialization
    void Start()
    {
        target = transform.TransformPoint(0, 0, 0);
        EmptyMatrix(matrix);
    }

    // Update is called once per frame
    void Update()
    {
        float step = 100.0f * Time.deltaTime;
        float rot = 5.0f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, step);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rot);
        heading = playerScript.plane1Position - transform.position;
        dirNum = AngleDir(transform.forward, heading, transform.up);
        //print(dirNum);
    }

    public float AngleDir(Vector3 fwd, Vector3 targetDir, Vector3 up)
    {
        Vector3 perp = Vector3.Cross(fwd, targetDir);
        float dir = Vector3.Dot(perp, up);
        return dir;
    }

    public void EmptyMatrix(Tuple3[,] matrix)
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                matrix[i, j] = new Tuple3(0, 0, 0);
            }

        }

    }

    public void FillMatrix(Tuple3[,] matrix)
    {
        for (int i = 0; i < 8; i++) 
        {
            for (int j = 0; j < 8; j++)
            {
                matrix[i, j] = new Tuple3(UnityEngine.Random.Range(1, 100), UnityEngine.Random.Range(1, 100), UnityEngine.Random.Range(1, 100));
            }
        }
    }

    public void PrintMatrix(Tuple3[,] matrix) {
        string row = "";
        for(int i = 0;i < 8;i++)
        {
            row = "";
            for(int j = 0;j < 8;j++)
            {
                row = row + "|" + matrix[i, j].Get();
            }
            Debug.Log(row);
        }

    }

    public void AiMove()
    {
        FillMatrix(matrix);
        PrintMatrix(matrix);

        float distance = Vector3.Distance(playerScript.plane1Position, transform.position);
        print("DirNum: " + dirNum);
        print("Distance: " + distance);
        if (dirNum < -100)
        {
            if (distance > 250)
            {
                print("Moved far left");
                MoveFarLeft();
            }
            else
            {
                print("Moved close left");
                MoveCloseLeft();
            }

        }
        else if (dirNum > 100)
        {
            if (distance > 250)
            {
                print("Moved far right");
                MoveFarRight();
            }
            else
            {
                print("Moved close right");
                MoveCloseRight();
            }

        }
        else
        {
            MoveCloseForward();
            print("Moved back left");
        }
    }


    public void MoveCloseForward()
    {
        target = transform.TransformPoint(0, 95, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);        
    }

    public void MoveCloseRight()
    {
        target = transform.TransformPoint(35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -30);
    }

    public void MoveCloseLeft()
    {
        target = transform.TransformPoint(-35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 30);
    }

    public void MoveFarForward()
    {
        target = transform.TransformPoint(0, 120, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);             
    }

    public void MoveFarRight()
    {
        target = transform.TransformPoint(40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -45);
    }

    public void MoveFarLeft()
    {
        target = transform.TransformPoint(-40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 45);
    }
    
    public void MoveBackLeft()
    {
        target = transform.TransformPoint(-20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

    public void MoveBackRight()
    {
        target = transform.TransformPoint(20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

}

