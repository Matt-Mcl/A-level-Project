﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class InRange : MonoBehaviour {

    public bool inRange = false;

    // Use this for initialization
    void Start() {

    }

	// Update is called once per frame
	void Update() {

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Plane2")
        {
            inRange = true;
            Debug.Log("In range: " + inRange);
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.name == "Plane2")
        {
            inRange = false;
            Debug.Log("In range: " + inRange);
        }
    }

}


