﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Movement : MonoBehaviour
{
    private Vector3 target;
    private Quaternion rotation;
    private Vector3 position;
    private int move;


    // Use this for initialization
    void Start()
    {
        target = transform.TransformPoint(0, 0, 0);
    }

    // Update is called once per frame
    void Update()
    { 
        float step = 100.0f * Time.deltaTime;
        float rot = 3.0f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, step);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rot);
    }

    public void aiMove()
    {
        move = Random.Range(1, 7);
        if (move == 1)
        {
            MoveCloseForward();
        }
        if (move == 2)
        {
            MoveCloseRight();
        }
        if (move == 3)
        {
            MoveCloseLeft();
        }
        if (move == 4)
        {
            MoveFarForward();
        }
        if (move == 5)
        {
            MoveFarRight();
        }
        if (move == 6)
        {
            MoveFarLeft();
        }
    }

    public void MoveCloseForward()
    {
        target = transform.TransformPoint(0, 95, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);        
    }

    public void MoveCloseRight()
    {
        target = transform.TransformPoint(35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -30);
    }

    public void MoveCloseLeft()
    {
        target = transform.TransformPoint(-35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 30);
    }

    public void MoveFarForward()
    {
        target = transform.TransformPoint(0, 120, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);             
    }

    public void MoveFarRight()
    {
        target = transform.TransformPoint(40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -45);
    }

    public void MoveFarLeft()
    {
        target = transform.TransformPoint(-40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 45);
    }

}
