﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {

    public Toggle_UI uiScript;
    public Movement playerScript;
    public AI_Movement aiScript;
    public ToggleButtons buttonToggle;
    public InRange playerRangeDetect;
    public InRange aiRangeDetect;
    public EdgeCollide edgeScript;
    public Teleport teleScript;
    private Vector3 parentPosition;
    private Quaternion parentRotation;
    private bool playerTurn = true;
    private float turnTime;


    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(playerTurn);
        if (playerTurn == true)
        {
            if (Time.time - turnTime > 1)  //1 second timer. 
            {
                buttonToggle.ButtonToggle(true);
            }
            
        }


        if (playerTurn == false)
        {
            buttonToggle.ButtonToggle(false);
            if (edgeScript.edgeCollided == true)
            {
                teleScript.target = playerScript.plane1Position;
                teleScript.rotation = playerScript.plane1Rotation;
                playerTurn = true;
            }

            if (Time.time - turnTime > 1)  //1 second artificial timer. 
            {                              //Makes it seem like the AI is is taking time to process. 
                playerScript.PlayerMove(); //Likely remove/change implementation later
                aiScript.AiMove();
                playerTurn = true;
                turnTime = Time.time;
            }
        }

    }

    public void ChangeTurn()
    {
        playerTurn = !playerTurn;
        turnTime = Time.time;
    }

}
