﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneCollisions : MonoBehaviour {

    public bool collided = false;
    public bool collidedAI = false;

    // Use this for initialization
    void Start() {

    }

    // Update is called once per frame
    void Update() {

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Plane2")
        {
            collided = true;
            Debug.Log("Collided: " + collided);
        }

        if (other.gameObject.name == "Plane1")
        {
            collidedAI = true;
            Debug.Log("AI Collided: " + collidedAI);
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.name == "Plane2")
        {
            collided = false;
            Debug.Log("Collided: " + collided);
        }

        if (other.gameObject.name == "Plane1")
        {
            collidedAI = false;
            Debug.Log("AI Collided: " + collidedAI);
        }
    }
}

