﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Teleport : MonoBehaviour {
    public Vector3 target;
    public Quaternion rotation;
    private Vector3 position;
    //public Vector3 telePosition;
    //public Quaternion teleRotation;

    // Use this for initialization
    void Start()
    {
        target = transform.TransformPoint(0, 0, 0);
    }

    // Update is called once per frame
    void Update()
    {
        float step = 300.0f * Time.deltaTime;
        float rot = 100.0f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, step);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rot);
        //telePosition = transform.position;
        //teleRotation = transform.rotation;
    }

    public void MoveCloseForward()
    {
        target = transform.TransformPoint(0, 95, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 0);
    }

    public void MoveCloseRight()
    {
        target = transform.TransformPoint(35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -30);
    }

    public void MoveCloseLeft()
    {
        target = transform.TransformPoint(-35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 30);
    }

    public void MoveFarForward()
    {
        target = transform.TransformPoint(0, 120, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 0);
    }

    public void MoveFarRight()
    {
        target = transform.TransformPoint(40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -45);
    }

    public void MoveFarLeft()
    {
        target = transform.TransformPoint(-40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 45);
    }

    public void MoveBackLeft()
    {
        target = transform.TransformPoint(-20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

    public void MoveBackRight()
    {
        target = transform.TransformPoint(20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }



}

