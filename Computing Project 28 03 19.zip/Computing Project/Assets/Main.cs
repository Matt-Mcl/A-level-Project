﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {

    public Toggle_UI uiScript;
    public Movement playerScript;
    public AI_Movement aiScript;
    public ToggleButtons buttonToggle;
    public InRange rangeScript;
    public InRange rangeScriptAI;
    public EdgeCollide edgeScript;
    public Teleport teleScript;
    private Vector3 parentPosition;
    private Quaternion parentRotation;
    private bool playerTurn = true;
    private float turnTime;
    private bool win;


    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(playerTurn);
        if (playerTurn == true)
        {
            if (Time.time - turnTime > 1 && !buttonToggle.GetButtonsEnabled())  //1 second timer. 
            {
                //print("CHICKEN");
                buttonToggle.ButtonToggle(true);
                win = CheckWinner();
                if (win == true)
                {
                    print("Quitting...");
                    Application.Quit();
                }
            }
            
        }


        if (playerTurn == false)
        {
            buttonToggle.ButtonToggle(false);
            if (edgeScript.edgeCollided == true) //If player move exits playzone 
            {
                teleScript.target = playerScript.plane1Position; //Move teleporter back to player
                teleScript.rotation = playerScript.plane1Rotation;
                playerTurn = true;
            }

            if (Time.time - turnTime > 1)  //1 second artificial timer. 
            {                              
                playerScript.PlayerMove(); //Likely remove/change implementation later (of timer)
                aiScript.AiMove(aiScript.matrix);
                ChangeTurn();
            }
        }

    }

    public void ChangeTurn()
    {
        playerTurn = !playerTurn;
        turnTime = Time.time;
    }

    public bool CheckWinner()
    {
        if (rangeScript.inRange == false && rangeScriptAI.inRangeAI == false)
        {
            print("Game Continues");
            return false;
        }
        else if (rangeScript.inRange == true && rangeScriptAI.inRangeAI == true)
        {
            print("Game Continues (Both can shoot)");
            return false;
        }
        else if (rangeScript.inRange == true && rangeScriptAI.inRangeAI == false)
        {
            print("Player Wins");
            return true;
        }
        else if (rangeScript.inRange == false && rangeScriptAI.inRangeAI == true)
        {
            print("AI Wins");
            return true;
        }

        return false;
    }


}
