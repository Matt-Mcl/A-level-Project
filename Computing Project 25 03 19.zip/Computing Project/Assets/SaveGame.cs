﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveGame : MonoBehaviour {

    public Movement playerScript;
    public AI_Movement aiScript;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void Save() {
		PlayerPrefs.SetFloat("plane1PositionX", playerScript.plane1Position.x);
        PlayerPrefs.SetFloat("plane1PositionY", playerScript.plane1Position.y);
        PlayerPrefs.SetFloat("plane1Rotation", playerScript.plane1SaveRotation);

        PlayerPrefs.Save();
        print("Saved");
        //PlayerPrefs.SetFloat("plane1Rotation", playerScript.plane1Rotation);

    }


}
