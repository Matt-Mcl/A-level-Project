﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Movement : MonoBehaviour
{
    private Vector3 target;
    private Quaternion rotation;
    private Vector3 position;
    public Movement playerScript;
    public Vector3 plane2Position;
    public Quaternion plane2Rotation;

    public Tuple3[,] matrix = new Tuple3[8, 8]; //FOR DESIGN: discuss why I chose tuple3 over 3d array / (3 arrays)
    public int[,] payoff = new int[8, 8];

    public class Tuple3
    {
        public float distance;
        public float dirToPlayer;
        public float dirToAi;

        public Tuple3(float dist, float dtp, float dta)
        {
            this.distance = dist;
            this.dirToPlayer = dtp;
            this.dirToAi = dta;
        }

        public string Get()
        {
            double T1 = Math.Round(this.distance, 0);
            double T2 = Math.Round(this.dirToPlayer, 0);
            double T3 = Math.Round(this.dirToAi, 0);

            return string.Concat(T1 + "," + T2 + "," + T3);
        }

    }

    // Use this for initialization
    void Start()
    {
        target = transform.TransformPoint(0, 0, 0);
        EmptyMatrix(matrix);
    }

    // Update is called once per frame
    void Update()
    {
        float step = 100.0f * Time.deltaTime;
        float rot = 5.0f * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, target, step);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rot);
        plane2Position = transform.position;
        plane2Rotation = transform.rotation;

        /* //Reference code for finding angle from AI to player
        heading = playerScript.plane1Position - transform.position;
        cosAngle = Vector3.Dot(heading, transform.up) / (heading.magnitude * transform.up.magnitude);
        turnAngle = Mathf.Acos(cosAngle);
        if (Vector3.Cross(transform.up, heading).z > 0)
        {
            signAngle = 1;
        }
        else
        {
            signAngle = -1;
        }
        turnAngle = turnAngle * signAngle;
        turnAngle = turnAngle * Mathf.Rad2Deg;
        */
    }

    public float AngleDir(Vector3 targetDir, Vector3 up)
    {
        float cosAngle = Vector3.Dot(targetDir, up) / (targetDir.magnitude * up.magnitude);
        float turnAngle = Mathf.Acos(cosAngle);
        int sign;
        if (Vector3.Cross(up, targetDir).z > 0)
        {
            sign = 1;
        }
        else
        {
            sign = -1;
        }
        turnAngle = turnAngle * sign;
        turnAngle = turnAngle * Mathf.Rad2Deg;
        return turnAngle;
    }


    public void EmptyMatrix(Tuple3[,] matrix) //Fills matrix with (0,0,0) tuples (emptying it)
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                matrix[i, j] = new Tuple3(0, 0, 0);
            }
        }
    }

    public Tuple3 CreateData(int i, int j)
    {
        Vector3 player = playerScript.plane1Position;
        Vector3 ai = transform.position;
        int playerRot = 0;
        int aiRot = 0;

        switch (i)
        {
            case 0:
                player += new Vector3(0, 95, 0);
                break;
            case 1:
                player += new Vector3(35, 90, 0);
                playerRot = -30;
                break;
            case 2:
                player += new Vector3(-35, 95, 0);
                playerRot = 30;
                break;
            case 3:
                player += new Vector3(0, 120, 0);
                break;
            case 4:
                player += new Vector3(40, 105, 0);
                playerRot = -45;
                break;
            case 5:
                player += new Vector3(-40, 105, 0);
                playerRot = 45;
                break;
            case 6:
                player += new Vector3(-20, -90, 0);
                playerRot = 180;
                break;
            case 7:
                player += new Vector3(20, -90, 0);
                playerRot = 180;
                break;

        } 

        switch(j)
        {
            case 0:
                ai += new Vector3(0, 95, 0);
                break;
            case 1:
                ai += new Vector3(35, 90, 0);
                aiRot = -30;
                break;
            case 2:
                ai += new Vector3(-35, 95, 0);
                aiRot = 30;
                break;
            case 3:
                ai += new Vector3(0, 120, 0);
                break;
            case 4:
                ai += new Vector3(40, 105, 0);
                aiRot = -45;
                break;
            case 5:
                ai += new Vector3(-40, 105, 0);
                aiRot = 45;
                break;
            case 6:
                ai += new Vector3(-20, -90, 0);
                aiRot = 180;
                break;
            case 7:
                ai += new Vector3(20, -90, 0);
                aiRot = 180;
                break;
        } 

        float distance = Vector3.Distance(player, ai);
        //dirToPlayer
        float aiNewAngle = Mathf.Deg2Rad * (transform.eulerAngles.z + aiRot + 90);
        Vector3 aiNewVector = new Vector3(Mathf.Cos(aiNewAngle), Mathf.Sin(aiNewAngle), 0);
        Vector3 heading1 = player - ai;
        float dirToPlayer = AngleDir(heading1, aiNewVector);
        //dirToAI
        float pNewAngle = Mathf.Deg2Rad * (playerScript.transform.eulerAngles.z + playerRot + 90);
        Vector3 pNewVector = new Vector3(Mathf.Cos(pNewAngle), Mathf.Sin(pNewAngle), 0);
        Vector3 heading2 = ai - player;
        float dirToAi = AngleDir(heading2, pNewVector);

        return new Tuple3(distance,dirToPlayer,dirToAi);
    }

    public void FillMatrix(Tuple3[,] matrix)
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                matrix[i,j] = CreateData(i, j);
            }
        }
    }

    public void PrintMatrix(Tuple3[,] matrix) {
        string row = "";
        for(int i = 0;i < 8;i++)
        {
            row = "";
            for(int j = 0;j < 8;j++)
            { 
                row = row + "|" + matrix[i, j].Get();
            }
            Debug.Log(row);
        }
    }

    public void PrintPayoff(int[,] payoff)
    {
        string row = "";
        for (int i = 0; i < 8; i++)
        {
            row = "";
            for (int j = 0; j < 8; j++)
            {
                row = row + "|" + payoff[i, j];
            }
            Debug.Log(row);
        }
    }

    public int CreatePayoff(Tuple3[,] matrix, int i, int j)
    {
        float dtp = matrix[i, j].dirToPlayer;
        float dta = matrix[i, j].dirToAi;
        print(i +", " + j+": " + dtp + " | " + dta);

        if (dtp >= -45 && dtp <= 45)
        {
            if (dta >= -45 && dta <= 45)
            {
                return -1;
            }
            if (dta >= 45 && dta <= 135)
            {
                return 2;
            }
            if (dta <= -45 && dta >= -135)
            {
                return 2;
            }
            /*
            if (Mathf.Abs(dta) >= 45 && Math.Abs(dta) <= 135)
            {
                return 2;
            }
            */
            if (dta >= -135 && dta <= 135)
            {
                print("3 RETURNED");
                return 3;
            }
            return -91;
        }

        if (dtp >= 45 && dtp <= 135)
        {
            if (dta >= -45 && dta <= 45)
            {
                return -2;
            }
            if (dta >= 45 && dta <= 135)
            {
                return 0;
            }
            if (dta <= -45 && dta >= -135)
            {
                return 0;
            }
            /*
            if (Mathf.Abs(dta) >= 45 && Math.Abs(dta) <= 135)
            {
                return 0;
            }
            */
            if (dta >= -135 && dta <= 135)
            {
                return 0;
            }
            return -92;
        }

        if (dtp <= -45 && dtp >= -135)
        {
            if (dta >= -45 && dta <= 45)
            {
                return -2;
            }
            if (dta >= 45 && dta <= 135)
            {
                return 0;
            }
            if (dta <= -45 && dta >= -135)
            {
                return 0;
            }
            /*
            if (Mathf.Abs(dta) >= 45 && Math.Abs(dta) <= 135)
            {
                return 0;
            }
            */
            if (dta >= -135 && dta <= 135)
            {
                return 0;
            }
            return -93;
        }

        if (dtp >= -135 && dtp <= 135)
        {
            if (dta >= -45 && dta <= 45)
            {
                return -3;
            }
            if (dta >= 45 && dta <= 135)
            {
                return 0;
            }
            if (dta <= -45 && dta >= -135)
            {
                return 0;
            }
            /*
            if (Mathf.Abs(dta) >= 45 && Math.Abs(dta) <= 135)
            {
                return 0;
            }
            */
            if (dta >= -135 && dta <= 135)
            {
                return 0;
            }
            return -94;
        }

        print(matrix[i, j].Get());
        return -100;
        
    }

    public void ChooseMove(int[,] payoff)
    {
        int max = payoff[0, 0];
        int index = 0;
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                int temp = payoff[i, j];
                if (temp > max)
                {
                    max = temp;
                    index = j;
                    print(max);
                }
                //print(max);
            }
        }
        print("Final Max " + max);
        //print(index);

        switch (index)
        {
            case 0:
                MoveCloseForward();
                break;
            case 1:
                MoveCloseRight();
                break;
            case 2:
                MoveCloseLeft();
                break;
            case 3:
                MoveFarForward();
                break;
            case 4:
                MoveFarRight();
                break;
            case 5:
                MoveFarLeft();
                break;
            case 6:
                MoveBackLeft();
                break;
            case 7:
                MoveBackRight();
                break;
        }
    }


    public void AiMove(Tuple3[,] matrix)
    {
        //print("aiCurrV" + transform.up);
        //print("pCurrV " + playerScript.transform.up);

        FillMatrix(matrix);
        PrintMatrix(matrix);

        //print(Mathf.Round(matrix[0, 0].distance));
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                payoff[i, j] = CreatePayoff(matrix, i, j);
            }
        }

        PrintPayoff(payoff);

        ChooseMove(payoff);

    }


    public void MoveCloseForward()
    {
        target = transform.TransformPoint(0, 95, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);        
    }

    public void MoveCloseRight()
    {
        target = transform.TransformPoint(35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -30);
    }

    public void MoveCloseLeft()
    {
        target = transform.TransformPoint(-35, 90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 30);
    }

    public void MoveFarForward()
    {
        target = transform.TransformPoint(0, 120, 0);
        //rotation = transform.rotation * Quaternion.Euler(0, 0, 0);             
    }

    public void MoveFarRight()
    {
        target = transform.TransformPoint(40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, -45);
    }

    public void MoveFarLeft()
    {
        target = transform.TransformPoint(-40, 105, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 45);
    }
    
    public void MoveBackLeft()
    {
        target = transform.TransformPoint(-20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

    public void MoveBackRight()
    {
        target = transform.TransformPoint(20, -90, 0);
        rotation = transform.rotation * Quaternion.Euler(0, 0, 180);
    }

}

